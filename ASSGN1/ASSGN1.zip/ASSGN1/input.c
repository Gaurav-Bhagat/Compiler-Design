int main(){
	int add,x,y;
	float val;
	char c;
	add = x + y;  //add
	//int a = 10;
	y = 23;
	int div = x / y;
}